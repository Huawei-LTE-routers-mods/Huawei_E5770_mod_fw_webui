// JavaScript Document

$(document).ready(function() {

    $('#link_go_to_home').click(function() {
        window.location = HOME_PAGE_URL;
    });
});
